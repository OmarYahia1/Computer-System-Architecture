
public class ins {
	
	
	int instr = 0;
	int opcode = 0;
	int r1 = 0;
	int r2 = 0;
	int r3 = 0;
	int shamt = 0;
	int imm = 0;
	int addr = 0;
	int valueR2 = 0;
	int valueR3 = 0;
	int output = 0;
	Computer c;
	int timer=0;
	public ins() {
		
	}
	
	public void fetch() throws Exception {
		
		instr = c.memory[c.pc];
		c.pc++;

		
	}
	
	public void decode() throws Exception {
		
		
		int temp=0;
		
		temp = 0b11110000000000000000000000000000 & instr;
		opcode = temp >>>28;
		
		temp = 0b00001111100000000000000000000000 & instr;
		r1 = temp >>>23;
		
		
		temp = 0b00000000011111000000000000000000 & instr;
		r2 = temp >>>18;

		if(r2>31) {
			valueR2 = 0;
		}
		else {
			valueR2 = c.registerFile[r2];
		}


		
		
		temp = 0b00000000000000111110000000000000 & instr;
		r3 = temp >>>13;
		if(r3>31) {
			valueR3 = 0;
		}
		else {
			valueR3 = c.registerFile[r3];
		}
		
		
		
		shamt = 0b00000000000000000001111111111111 & instr;
		
		imm = 0b00000000000000111111111111111111 & instr;
		imm = imm<<14;
		imm = imm>>14;
		
		addr = 0b00001111111111111111111111111111 & instr;

		
		
	}
	
	public void execute() {
		int temp;
		switch(opcode) {
		case 0:
			output = valueR2 + valueR3;
			break;
		case 1:
			output = valueR2 - valueR3;
			break;
		case 2:
			output = valueR2 * valueR3;
			break;
		case 4:
			if(c.registerFile[r1] == valueR2) {
				c.old = c.pc;
				c.pc = c.pc+imm-1;
				c.branch = true;
			}
			break;
		case 3:
			output = imm;
			break;
		case 5: 
			output = valueR2 & valueR3;
			break;
		case 6: 
			output = valueR2 ^ imm;
			break;
		case 7:
			c.old = c.pc;
			temp = c.pc & 0b11110000000000000000000000000000;
			c.pc = temp + addr;
			break;
		case 8:
			output = valueR2 << shamt;
			break;
		case 9: 
			output = valueR2 >>> shamt;
			break;
		case 10:
			output = valueR2 + imm;
			break;
		case 11:
			output = valueR2 + imm;
			
			break;			
		}
	}
	

	
	public void Memory() {
		
		if(opcode == 10) {
			output = c.memory[output];
		}
		
		if(opcode == 11) {
			c.memory[output] = c.registerFile[r1];
		}
		
	
	
	}
	public void WriteBack() {
		if(opcode != 11 && opcode!=7 && opcode!=4) {
			c.registerFile[r1] = output;
			if(r1 == 0) {
				c.registerFile[r1] = 0;
			}
		}
		
	}
	
	
	
}

